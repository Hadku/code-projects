/*Hadi Kudoda 1002148663*/ 

#include <stdio.h>

int GetValue(char GeVal1[], char GeVal2[])
{
    int Value;

    printf("Enter the %s value for the %s loop ", GeVal1, GeVal2);
    scanf("%d", &Value);
    
    return Value;
}

int CheckValues(int start, int end)
{
    
    if (start > end)
    {
        printf("Starting value must be less than ending value. Please reenter\n");
        return 1;
    }
    else
    {
        return 0;
    }
}

int main()
{
    char symbol;
    int outval;
    int outval2;
    int midval;
    int midval2;
    int innval;
    int innval2;
    
    printf("Enter the character you want to use ");
    scanf("%c", &symbol);
        
    do
    {
        outval = GetValue("Starting", "Outer"); 
        outval2 = GetValue("Ending", "Outer");
    }
    while (CheckValues(outval, outval2));
    
    do
    {
        midval = GetValue("Starting", "Middle"); 
        midval2 = GetValue("Ending", "Middle");
    }
    while (CheckValues(midval, midval2));

    do
    {
        innval = GetValue("Starting", "Inner"); 
        innval2 = GetValue("Ending", "Inner");
    }
    while (CheckValues(innval, innval2));

       
    
    for (int i = outval; i < outval2; i++)
    {
        for (int j = midval; j < midval2; j++)
        {
            for (int k = innval; k < innval2; k++)
            {
                printf("%c", symbol);
            }
            printf("\n");
        }
        printf("\n");
    }
    printf("\n");
}