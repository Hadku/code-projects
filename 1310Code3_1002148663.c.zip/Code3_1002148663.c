/*Hadi Kudoda 1002148663*/ 

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int get8ball()
{
    return rand() % 20 + 1;

}

int getmenu()
{
    int menu = 0;

    printf("Pick a question to answer:\n");
    printf("1. What color is the sky?\n");
    printf("2. What will you do today?\n");
    printf("3. How many fingers?\n"); 
    printf("4. What day is it today?\n");
    printf("5. What does 1+1 equal?\n");
    printf("Enter a choice between 1 and 5: ");
    scanf("%d",&menu);

    while (menu < 1 || menu > 5)
    {
        printf("Enter a choice between 1 and 5: ");
        scanf("%d",&menu);
    }

    return menu;
}
int main()
{
    int menu;
    menu = getmenu();


    printf("The answer to question ");
    printf("%d", menu);
    printf(" is...\n");
    


    int eightball;
    srand(time(0));
    eightball = get8ball();

        

    switch (eightball)
    {
        case 1: 
            printf("It is certain");
            break;
        case 2: 
            printf("It is decidedly so");
            break;
        case 3: 
            printf("Without a doubt");
            break;
        case 4: 
                printf("Yes definitely");
            break;
        case 5: 
            printf("You may rely on it");
            break;
        case 6:
            printf("As I see it, yes");
            break;
        case 7:
            printf("Most likely");
            break;
        case 8:
            printf("Outlook good");
            break;
        case 9:
            printf("Yes");
            break;
        case 10:
            printf("Signs point to yes");
            break;
        case 11:
            printf("Reply hazy, try again");
            break;
        case 12:
            printf("Ask again later");
            break;
        case 13:
            printf("Better not tell you now");
            break;
        case 14:
            printf("Cannot predict now");
            break;
        case 15:
            printf("Concentrate and ask again");
            break;
        case 16:
            printf("Don't count on it");
            break;
        case 17:
            printf("My reply is no");
            break;
        case 18:
            printf("My sources say no");
            break;
        case 19:
            printf("Outlook not so good");
            break;
        case 20:
            printf("Very doubtful");
            break;
        default:
            printf("I don't know how I got here.");
            break;
    }
    return 0;
}   
