/*Hadi Kudoda 1002148663*/ 

#include <stdio.h>

int main()
{
   char response;
   printf("Did your friend vist?");
   scanf(" %c", &response);


   if (response == 'Y')
   {
      printf("Weekend plans-have fun at the movies with your friends!");
   }
   else
   {
      printf("Your friends weren't able to visit so you need to make alternate plans.\nIs the weather nice?");    
      scanf(" %c", &response);
      if (response == 'Y')
      {
         printf("weekend plans-ride bike in the park!");
      }
      else 
      {
         printf("Oh, so the weather is bad.\n Do you have enough money to go shopping?");
         scanf(" %c", &response);
         if (response == 'Y')
         {
            printf("Weekend plans-go shopping-don't spend too much!!");
         }
         else
         {
            printf("Weekend plans-stay home and play video games!!");
         }   
      }
   }
}