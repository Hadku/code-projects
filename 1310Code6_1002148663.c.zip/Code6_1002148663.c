/*Hadi Kudoda 1002148663*/




#include <stdio.h>
#include <ctype.h>




#define MAX_ROWS 9
#define MAX_COLS 9
#define TICKET_LIMIT 4





void FillMovieTheater(char MovieTheater[MAX_ROWS][MAX_COLS], int rows, int seats) 
{
    for (int i = 0; i < rows; ++i) 
    {
        for (int j = 0; j < seats; ++j) 
        {
            MovieTheater[i][j] = 'O';
        }
    }
}


void PrintSeatMap(char MovieTheater[MAX_ROWS][MAX_COLS], int numofrows, int numofcols)
{
    printf("\n       ");

    for (int i = 1; i <= numofcols; i++)
    {
        
        printf("Seat %d ", i);
    }
    printf("\n");


    for (int i = 0; i < numofrows; i++)
    {
        printf("Row %c  ", 'A' + i);
        
        
        for (int j = 0; j < numofcols; j++)
        {
            
            
            printf("%-6c ", MovieTheater[i][j]);
        }
        printf("\n");
    }
}


int IsSeatSold(char MovieTheater[MAX_ROWS][MAX_COLS], int row, int col) 
{
    int var;

    
    if (MovieTheater[row][col] == 'X') 
    {
        var = 1;
    } 
    else 
    {
        MovieTheater[row][col] = 'X';
        var = 0;
    }

    return var;
}

int main(void)
{
    int tickets_purchased = 0;
    int tickets_sold = 0;
    int ArrayRow;
    int ArrayCol;
    int num_rows;
    int num_cols;
    char user_row;
    int user_col; 
    char MovieTheater[MAX_ROWS][MAX_COLS];

    do
    {
        
        printf("How many rows does your movie theater have? (1-%d) ", MAX_ROWS);
        scanf("%d", &num_rows);

        if (num_rows != 1 || num_rows < 1 || num_rows > MAX_ROWS)
        {
            printf("Rows must be between 1 and %d. Please reenter.\n\n", MAX_ROWS);
        }
    }
    while (num_rows < 1 || num_rows > MAX_ROWS);

    do
    {
        printf("How many seats are there per row? (1-%d) ", MAX_COLS);
        scanf("%d", &num_cols);
        
        if ( num_cols != 1 || num_cols < 1 || num_cols > MAX_COLS)
        {
            printf("Columns must be between 1 and %d. Please reenter.\n\n", MAX_COLS);
        }
    }
    while (num_cols < 1 || num_cols > MAX_COLS);

    FillMovieTheater(MovieTheater, num_rows, num_cols);

    do
    {
        
        printf("How many tickets would you like to purchase? (limit %d) ", TICKET_LIMIT);

        
        if (scanf("%d", &tickets_purchased) != 1 || tickets_purchased < 0 || tickets_purchased > TICKET_LIMIT)
        {
            
            printf("This is a special showing - limit of %d tickets per purchase\n", TICKET_LIMIT);
        }
    }
    while (tickets_purchased < 0 || tickets_purchased > TICKET_LIMIT);

    
    
    if (tickets_purchased == 0)
    {
        printf("No movie for you!\n");
    }
    
    
    else
    {
        while (tickets_sold < tickets_purchased)
        {
            
            
            PrintSeatMap(MovieTheater, num_rows, num_cols);

            printf("\nEnter seat choice by entering the row and seat\n\n");
            
            
            
            printf("Please pick a seat ");
            
            scanf(" %c%d", &user_row, &ArrayCol);

            user_row = toupper(user_row);



            printf("\n");

            if (ArrayCol < 1 || ArrayCol > num_cols || user_row < 'A' || user_row >= 'A' + num_rows)
            {
                printf("\nThat seat is not in this theater!!\n\n");
            
            
            }
            else if (IsSeatSold(MovieTheater, user_row - 'A', ArrayCol - 1))
            {
            
                printf("\nSeat %c%d is already sold. Pick a different seat.\n\n", user_row, ArrayCol);
            }
            else
            {

                tickets_sold++;
            }
        }

        printf("All tickets have been sold.\n");
        
        
        
        printf("Please find your way to your seats using this map...\n\n");
        
        PrintSeatMap(MovieTheater, num_rows, num_cols);
        
        
        printf("Enjoy your movie!\n");
    }

    return 0;

}
