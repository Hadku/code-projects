/*Hadi Kudoda 1002148663*/

#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>


#define MAX_ROWS 9
#define MAX_COLS 9
#define TICKET_LIMIT 4





void FillMovieTheater(char MovieTheater[MAX_ROWS][MAX_COLS], int rows, int seats, char newarray[]) 
{
    for (int i = 0; i < rows; ++i) 
    {
        for (int j = 0; j < seats; ++j) 
        {
            MovieTheater[i][j] = newarray[j];
        }
    }
}



void PrintSeatMap(char MovieTheater[MAX_ROWS][MAX_COLS], int numofrows, int numofcols)
{
    printf("\n       ");

    for (int i = 1; i <= numofcols; i++)
    {
        
        printf("Seat %d ", i);
    }
    printf("\n");


    for (int i = 0; i < numofrows; i++)
    {
        printf("Row %c  ", 'A' + i);
        
        
        for (int j = 0; j < numofcols; j++)
        {
            
            
            printf("%-6c ", MovieTheater[i][j]);
        }
        printf("\n");
    }
}




int IsSeatSold(char MovieTheater[MAX_ROWS][MAX_COLS], int row, int col) 
{
    int var;

    if (MovieTheater[row][col] == 'X') 
    {
        var = 1;
    } 
    else 
    {
        MovieTheater[row][col] = 'X';
        var = 0;
    }

    return var;
}


void WriteMovieTheater(char MovieTheater[MAX_ROWS][MAX_COLS], int numofrows, int numofcols)
{
    char filename[100];
    FILE *outputfile = NULL;
    printf("Enter output filename ");
    scanf("%s", filename);
    outputfile = fopen(filename, "w+");

    if(outputfile == NULL)
    {
        printf("file did not open... exiting...\n");
        exit(0);
    }
    
    fprintf(outputfile, "%d %d\n", numofrows, numofcols);
    
    
    for (int i = 0; i < numofrows; i++)
    {
        for (int j = 0; j < numofcols; j++)
        {
            fprintf(outputfile, "%c", MovieTheater[i][j]);
        }
        
    }


    fclose(outputfile);

}

int main(void)
{
    
    int tickets_purchased = 0;
    int tickets_sold = 0;
    int ArrayRow;
    int ArrayCol;
    int num_rows;
    int num_cols;
    char user_row;
    int user_col; 
    
    char MovieTheater[MAX_ROWS][MAX_COLS] = {};
    
    FILE *FFH = NULL;
    
    char infilename[100] = {};
    char sizeofarr[MAX_ROWS * MAX_COLS] = {};


    
    printf("Enter the name of your Movie Theater file ");
    scanf("%s", infilename);
    
    FFH = fopen(infilename, "r+");
    
    if(FFH == NULL)
    {
        printf("file did not open... exiting...\n");
        exit(0);
    }
    
    fscanf(FFH, "%d %d", &num_rows, &num_cols);

    fgets(sizeofarr, sizeof(sizeofarr), FFH);
    
    fscanf(FFH, "%s", sizeofarr);

    fclose(FFH);

    FillMovieTheater(MovieTheater, num_rows, num_cols, sizeofarr);

    do
    {
        printf("How many tickets would you like to purchase? (limit %d) ", TICKET_LIMIT);
        scanf("%d", &tickets_purchased);

        if (tickets_purchased < 0 || tickets_purchased > TICKET_LIMIT)
        {
            printf("This is a special showing - limit of %d tickets per purchase\n", TICKET_LIMIT);
        }
    }
    while (tickets_purchased < 0 || tickets_purchased > TICKET_LIMIT);
    
    if (tickets_purchased == 0)
    {
        printf("No movie for you!\n");
        WriteMovieTheater(MovieTheater, num_rows, num_cols);
    }
    else
    {
        while (tickets_sold < tickets_purchased)
        {
            PrintSeatMap(MovieTheater, num_rows, num_rows + 1);
            printf("\nEnter seat choice by entering the row and seat\nPlease pick a seat ");

            scanf(" %c%d", &user_row, &ArrayCol);
            user_row = toupper(user_row);


            printf("\n");
            
            if (ArrayCol < 1 || ArrayCol > num_cols || user_row < 'A' || user_row >= 'A' + num_rows)
            {
                printf("\nThat seat is not in this theater!!\n\n");
            }
            
            else if (IsSeatSold(MovieTheater, user_row - 'A', ArrayCol - 1))
            {
                printf("\nSeat %c%d is already sold. Pick a different seat.\n\n", user_row, ArrayCol);
            }
            else
            {
                tickets_sold++;
            }
            
        }

        printf("All tickets sold\n");

        printf("Please find your way to your seats using this map...\n\n");
        
        PrintSeatMap(MovieTheater, num_rows, num_cols);
        
        printf("\nEnjoy your movie!\n");

        WriteMovieTheater(MovieTheater, num_rows, num_cols);
    }
    
    
    return 0;
}